-- ==============================
-- Creamos una nueva base de datos
-- ===============================
CREATE DATABASE ExtEventsDB (SERVICE_OBJECTIVE ='S3')
